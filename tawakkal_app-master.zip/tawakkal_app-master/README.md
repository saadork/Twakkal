# About Twakkal
Twakkal , Inc is an Arab startup that mainly provides taxi services where individuals can hail a taxi in an app on their phone. 

### Login Screen Screenshot
![Login Screen Screenshot](./screenshots/2_Sign_Up_Screens/2.4_Login.jpg?raw=true "Title")


