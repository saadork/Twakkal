package com.example.hey_taxi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
