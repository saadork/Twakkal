class PackageDetail{
	final String title;
	final String subtitle;
	final String validity;
	final String price;
	PackageDetail(this.title, this.subtitle, this.validity, this.price);
}
