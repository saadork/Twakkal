import 'package:flutter/material.dart';
var primaryColor = Color(0xFF205CBe);

const passwordRegexRule = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@\$!%*#?&])[A-Za-z\\d@\$!%*#?&]{8,}\$";


